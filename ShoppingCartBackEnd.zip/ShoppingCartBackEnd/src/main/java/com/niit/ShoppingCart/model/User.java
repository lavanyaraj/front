package com.niit.ShoppingCart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
    @Entity
	@Table(name="USER")
	@Component

		
	public class User {	
		
		private String id;
		private String name;
		private String password;
		private  String mobile;
		private  String mail;
		private  String address;
		
		
		@Id
		@Column(name="ID")
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		
		@Column(name="NAME")
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		@Column(name="PASSWORD")
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
		@Column(name="MOBILE")
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		
		@Column(name="MAIL")
		public String getMail() {
			return mail;
		}
		public void setMail(String mail) {
			this.mail = mail;
		}
		
		@Column(name="ADDRESS")
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
	}