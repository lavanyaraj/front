package com.niit.ShoppingCart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ShoppingCart.dao.SupplierDAO;
import com.niit.ShoppingCart.model.Supplier;

public class SupplierTest {
public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context  = new AnnotationConfigApplicationContext();
		context.scan("com.niit.*");
		context.refresh();
		
		Supplier supplier = (Supplier) context.getBean("supplier");
	
	    SupplierDAO supplierDAO = (SupplierDAO)  context.getBean("supplierDAO");
	    
	    
	    supplier.setId("OG125");
        supplier.setName("OGNAME125");
        supplier.setAddress("OGDESC125");

       
        supplierDAO.saveorUpdate(supplier);
       




}


}

