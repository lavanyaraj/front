package com.niit.ShoppingCart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ShoppingCart.dao.UserDAO;
import com.niit.ShoppingCart.model.User;

public class UserTest {
public static void main(String[] args) {
	AnnotationConfigApplicationContext context  = new AnnotationConfigApplicationContext();
	context.scan("com.niit.*");
	context.refresh();
	
	User user = (User) context.getBean("user");

    UserDAO userDAO = (UserDAO)  context.getBean("userDAO");
    
    
    user.setId("OG120");
    user.setName("OGNAME120");
    user.setPassword("OGPASSWORD120");
    user.setMobile("OGMOBILE120");
    user.setMail("OGMAIL120");
    user.setAddress("OGADDRESS120");

   
    userDAO.saveorUpdate(user);
   




}


}
