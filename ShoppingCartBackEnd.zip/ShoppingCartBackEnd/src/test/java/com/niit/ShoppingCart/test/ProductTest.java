package com.niit.ShoppingCart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.ShoppingCart.dao.ProductDAO;
import com.niit.ShoppingCart.model.Product;

public class ProductTest {
public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.niit.*");
	context.refresh();
	
	Product product = (Product) context.getBean("product");
	
    ProductDAO productDAO = (ProductDAO)  context.getBean("productDAO");

    product.setId("OG123");
    product.setName("OGNAME123");
    product.setDescription("OGDESC123");
    product.setPrice("OGPRICE123");
    
    productDAO.saveorUpdate(product);
    
	
}
}
