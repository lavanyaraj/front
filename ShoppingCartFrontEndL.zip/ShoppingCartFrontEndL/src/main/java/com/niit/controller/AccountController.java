package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.*;
import com.niit.entities.*;
import org.springframework.web.bind.annotation.*;


@Controller
public class AccountController {
	private Object message;

	@RequestMapping("/login")
	public ModelAndView accountcontroller()
	{
		return new ModelAndView("welcome","message" , message);
	}

	@RequestMapping( value="/login", method = RequestMethod.GET)
	public String login(ModelMap mm){
		mm.put("account", new Account());
		return "login";
	}

	@RequestMapping( value="/login", method = RequestMethod.POST)
	public String login(@ModelAttribute(value="account") Account account ,ModelMap mm){
		if(account.getUsername().equals("niit")&& account.getPassword().equals("niit"))
		{
			mm.put("username", account.getUsername());
			return "home";
		}
		else
		{
			mm.put("message",  "invalid");
		    return "error";
		}
	}
	
}

